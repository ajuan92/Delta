#include <stdio.h> 
#include <string.h>   
#include <sys/socket.h>   
#include <arpa/inet.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h> 

#define IP_ADDRES "192.168.15.9"
   
void readString(char *array, char * prompt, int size);

int main(void)
{
    int sock;
    struct sockaddr_in server;
    char Message[10];
    char CommStr[20];
    char ServerR[256];
    enum {kMaxArgs = 6};
    int ArgC = 0;
    char *ArgV[kMaxArgs];
    char *Token;

    sock = socket(AF_INET , SOCK_STREAM , 0);
    if (sock == -1)
    {
        printf("Could not create socket ");
    }
     
    server.sin_addr.s_addr = inet_addr("192.168.15.9");
    server.sin_family = AF_INET;
    server.sin_port = htons(1500);
 
    if (connect(sock , (struct sockaddr *)&server , sizeof(server)) < 0)
    {
        printf("connect failed. Error");
        return 1;
    }
    while(1)
    {
        readString(CommStr, "Enter message:", 20);
        ArgC = 0;
        Token = strtok(CommStr, " ");
        while (Token && ArgC < kMaxArgs-1)
        {
            ArgV[ArgC++] = Token;
            Token = strtok(0," ");
        }
        ArgV[ArgC] = 0;
        printf("%d",ArgC);
        if(ArgC == 1)
        {
            if(strcmp(ArgV[0],"home") == 0)
            {
                Message[0] = 0x01;
                Message[1] = 0x00;
                Message[2] = 0x00;
                Message[3] = 0x00;
                Message[4] = 0x01;
            }
            else if(strcmp(ArgV[0],"stop") == 0)
            {
                Message[0] = 0x02;
                Message[1] = 0xFF;
                Message[2] = 0XFF;
                Message[3] = 0XFF;
                Message[4] = 0x00;   
            }
            else
            {
                printf("unknown command\n\r");
            }
        }
        else if(ArgC == 4)
        {
            if(strcmp(ArgV[0], "coord") == 0)
            {
                Message[0] = 0x04;
                Message[1] = atoi(ArgV[1]);         
                Message[2] = atoi(ArgV[2]);         
                Message[3] = atoi(ArgV[3]);         
                Message[4] = 0x01;
            }
            else
            {
                printf("unknown command\n\r");
            }
        }
        else
        {
            printf("unknown command\n\r");
        }
        
	if( write(sock, Message, 5) < 0)
        {
            printf("Send failed");
            return 1;
        }
         
        if( read(sock, ServerR, 255) < 0)
        {
            printf("receive failed");
            break;
        }else{
	   
	    if(ServerR[0] == 0XFF){
		Message[0] = 0xFF;	
	     	write(sock,Message,1);
	    }else{
	  	printf("Server message: %s",ServerR);
	   	//break;
	    }
	}
    }
    close(sock);
    return 0;
}

void readString(char *array, char * prompt, int size) {
    printf("%s", prompt);
    int c; int count=0;
    while ((c = getchar()) != '\n') {
        array[count] = c; count++;
    }
    array[count] = '\0';
}

